# Discord-Assistant
 Google assistant in a Discord bot

## Instalación

npm i

Configurar config-template.json

Borrar la parte de -template y que quede config.json

## Commands
join

stop

prefix + question
